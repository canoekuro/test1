/**
 * VibeCodingとコード自動化ツール概要プレゼンテーション用スクリプト
 */

document.addEventListener('DOMContentLoaded', () => {
  // タブ切り替え機能
  initTabs();
  
  // ナビゲーションリンクのスムーススクロール
  initSmoothScroll();
  
  // アクティブなナビゲーションリンクの更新
  initScrollSpy();
});

/**
 * タブ切り替え機能の初期化
 */
function initTabs() {
  const tabButtons = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-pane');
  
  tabButtons.forEach(button => {
    button.addEventListener('click', () => {
      const tabId = button.getAttribute('data-tab');
      
      // タブボタンのアクティブ状態を切り替え
      tabButtons.forEach(btn => btn.classList.remove('active'));
      button.classList.add('active');
      
      // タブコンテンツの表示/非表示を切り替え
      tabContents.forEach(content => {
        content.classList.remove('active');
        if (content.id === `${tabId}-content`) {
          content.classList.add('active');
        }
      });
    });
  });
}

/**
 * スムーススクロール機能の初期化
 */
function initSmoothScroll() {
  const navLinks = document.querySelectorAll('.nav-link');
  
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      
      const targetId = link.getAttribute('href');
      const targetElement = document.querySelector(targetId);
      
      if (targetElement) {
        // ヘッダーの高さを考慮したスクロール位置の調整
        const headerOffset = 80;
        const elementPosition = targetElement.getBoundingClientRect().top;
        const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
        
        window.scrollTo({
          top: offsetPosition,
          behavior: 'smooth'
        });
        
        // ナビゲーションリンクのアクティブ状態を更新
        navLinks.forEach(navLink => navLink.classList.remove('active'));
        link.classList.add('active');
      }
    });
  });
}

/**
 * スクロールスパイ機能の初期化
 * ユーザーがスクロールした位置に基づいてナビゲーションリンクのアクティブ状態を更新
 */
function initScrollSpy() {
  const sections = document.querySelectorAll('main section');
  const navLinks = document.querySelectorAll('.nav-link');
  
  window.addEventListener('scroll', () => {
    let current = '';
    
    sections.forEach(section => {
      const sectionTop = section.offsetTop;
      const sectionHeight = section.clientHeight;
      
      // ヘッダーの高さを考慮したスクロール位置の調整
      if (pageYOffset >= (sectionTop - 100)) {
        current = section.getAttribute('id');
      }
    });
    
    navLinks.forEach(link => {
      link.classList.remove('active');
      if (link.getAttribute('href') === `#${current}`) {
        link.classList.add('active');
      }
    });
  });
}

/**
 * ウィンドウサイズ変更時の処理
 */
window.addEventListener('resize', () => {
  // レスポンシブ対応のための追加処理があれば実装
});